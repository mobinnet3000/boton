import 'package:flutter/material.dart';
import 'package:get/get.dart';

// فرض می‌کنیم این فایل‌ها در پروژه شما وجود دارند و استایل‌ها و کامپوننت‌های سفارشی شما را شامل می‌شوند.
// import 'package:boton/components/myybotton.dart';
// import 'package:boton/constants/mypaddings.dart';
// import 'package:boton/constants/text_style.dart';
// import 'package:boton/components/responsivcont.dart';

// برای سادگی و نمایش کد، فرض می‌کنیم این کلاس‌ها به این شکل تعریف شده‌اند.
// شما باید این کلاس‌ها را از فایل‌های خودتان ایمپورت کنید.

class MyPadings {
  static const EdgeInsets large = EdgeInsets.all(24.0);
  static const EdgeInsets medium = EdgeInsets.all(16.0);
}

class RespCont extends StatelessWidget {
  final Widget child;
  const RespCont({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 600), // حداکثر عرض برای فرم در وب
        child: child,
      ),
    );
  }
}

class MyButton extends StatelessWidget {
  final VoidCallback ontap;
  final String matn;
  final Color? buttonColor;
  final Color? textColor;

  const MyButton({
    Key? key,
    required this.ontap,
    required this.matn,
    this.buttonColor,
    this.textColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: ontap,
      style: ElevatedButton.styleFrom(
        foregroundColor: textColor ?? Colors.white,
        backgroundColor: buttonColor ?? Theme.of(context).primaryColor,
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        minimumSize: const Size(150, 50), // حداقل اندازه برای دکمه
      ),
      child: Text(
        matn,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String? selectedRole;

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary; // Usually a contrasting color

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "ورود به سیستم",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: primaryColor,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white), // رنگ آیکون‌های اپ‌بار
      ),
      body: RespCont(
        child: SingleChildScrollView(
          padding: MyPadings.large,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // لوگو یا تصویر
              Padding(
                padding: const EdgeInsets.only(bottom: 40, top: 20),
                child: Image.asset(
                  'assets/images/logo.png', // مسیر لوگوی شما
                  height: 120,
                  width: 120,
                ),
              ),

              // انتخاب نوع کاربر
              Text(
                'لطفا نقش خود را انتخاب کنید:',
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),

              // دکمه‌های انتخاب نقش
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: MyButton(
                      ontap: () {
                        setState(() {
                          selectedRole = 'پیمانکار';
                          usernameController.clear();
                          passwordController.clear();
                        });
                      },
                      matn: 'ورود پیمانکار',
                      buttonColor: selectedRole == 'پیمانکار' ? accentColor : primaryColor,
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: MyButton(
                      ontap: () {
                        setState(() {
                          selectedRole = 'کارفرما';
                          usernameController.clear();
                          passwordController.clear();
                        });
                      },
                      matn: 'ورود کارفرما',
                      buttonColor: selectedRole == 'کارفرما' ? accentColor : primaryColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 40),

              // فرم ورود پس از انتخاب نقش
              if (selectedRole != null)
                Column(
                  children: [
                    Text(
                      "ورود به حساب کاربری $selectedRole",
                      style: theme.textTheme.titleLarge?.copyWith(
                        color: primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 30),

                    // فیلد نام کاربری
                    TextField(
                      controller: usernameController,
                      textAlign: TextAlign.right, // متن راست‌چین
                      textDirection: TextDirection.rtl, // جهت متن از راست به چپ
                      decoration: InputDecoration(
                        labelText: 'نام کاربری',
                        labelStyle: TextStyle(color: primaryColor),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: primaryColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: accentColor, width: 2),
                        ),
                        prefixIcon: Icon(Icons.person, color: primaryColor),
                        filled: true,
                        fillColor: Colors.blue.shade50,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // فیلد رمز عبور
                    TextField(
                      controller: passwordController,
                      obscureText: true,
                      textAlign: TextAlign.right, // متن راست‌چین
                      textDirection: TextDirection.rtl, // جهت متن از راست به چپ
                      decoration: InputDecoration(
                        labelText: 'رمز عبور',
                        labelStyle: TextStyle(color: primaryColor),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: primaryColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: accentColor, width: 2),
                        ),
                        prefixIcon: Icon(Icons.lock, color: primaryColor),
                        filled: true,
                        fillColor: Colors.blue.shade50,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // بخش فراموشی رمز عبور و ثبت نام
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(
                          onPressed: () {
                            Get.snackbar(
                              'فراموشی رمز عبور',
                              'برای بازیابی رمز عبور، لطفا با پشتیبانی تماس بگیرید یا مراحل مربوطه را دنبال کنید.',
                              backgroundColor: Colors.orange.shade100,
                              colorText: Colors.black87,
                              snackPosition: SnackPosition.BOTTOM,
                            );
                          },
                          child: Text(
                            "فراموشی رمز عبور؟",
                            style: TextStyle(color: primaryColor, fontWeight: FontWeight.w600),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Get.snackbar(
                              'ثبت نام',
                              'برای ثبت نام جدید، لطفا فرم مربوطه را پر کنید.',
                              backgroundColor: Colors.green.shade100,
                              colorText: Colors.black87,
                              snackPosition: SnackPosition.BOTTOM,
                            );
                          },
                          child: Text(
                            "ثبت نام",
                            style: TextStyle(color: primaryColor, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // دکمه ورود
                    MyButton(
                      ontap: () {
                        if (usernameController.text.isNotEmpty &&
                            passwordController.text.isNotEmpty) {
                          print(
                              "نام کاربری: ${usernameController.text}, رمز عبور: ${passwordController.text}");
                          Get.snackbar(
                            'ورود موفقیت‌آمیز',
                            'خوش آمدید، شما به سیستم وارد شدید.',
                            backgroundColor: Colors.green.shade100,
                            colorText: Colors.black87,
                            snackPosition: SnackPosition.TOP,
                          );
                          // اینجا می‌توانید منطق ورود به صفحه اصلی یا داشبورد را اضافه کنید.
                        } else {
                          Get.snackbar(
                            'خطا',
                            'لطفا نام کاربری و رمز عبور را وارد کنید.',
                            backgroundColor: Colors.red.shade100,
                            colorText: Colors.black87,
                            snackPosition: SnackPosition.TOP,
                          );
                        }
                      },
                      matn: 'ورود',
                      buttonColor: accentColor,
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'ورود به سیستم',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: Colors.blue.shade700, // رنگ اصلی آبی تیره
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.blue,
          accentColor: Colors.amber.shade700, // رنگ مکمل (برای دکمه‌های انتخاب شده یا دکمه ورود)
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Vazirmatn', // می‌توانید فونت فارسی مورد نظر خود را اینجا قرار دهید
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blue.shade700,
          foregroundColor: Colors.white,
          elevation: 4,
          shadowColor: Colors.black54,
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.blue.shade400),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.amber.shade700, width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Colors.blue.shade700,
            padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: Colors.blue.shade700,
          ),
        ),
      ),
      home: const LoginPage(),
    );
  }
}
