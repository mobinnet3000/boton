// lib/widgets/navigation/app_drawer_content.dart
import 'package:flutter/material.dart';

class AppDrawerContent extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onItemSelected;

  const AppDrawerContent({
    super.key,
    required this.selectedIndex,
    required this.onItemSelected,
  });

  @override
  Widget build(BuildContext context) {
    // این ویجت برای حالت موبایل (Drawer) استفاده می‌شود
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const DrawerHeader(
          decoration: BoxDecoration(color: Colors.blue),
          child: Text('آزمایشگاه بتن', style: TextStyle(color: Colors.white, fontSize: 24)),
        ),
        _buildListTile(context, index: 0, icon: Icons.dashboard_outlined, title: 'پیشخوان'),
        _buildListTile(context, index: 1, icon: Icons.folder_copy_outlined, title: 'پروژه‌ها'),
        _buildListTile(context, index: 2, icon: Icons.history_edu_outlined, title: 'گزارش فعالیت'),
        _buildListTile(context, index: 3, icon: Icons.monetization_on_outlined, title: 'گزارش مالی'),
        const Divider(),
        _buildListTile(context, index: 4, icon: Icons.admin_panel_settings_outlined, title: 'مدیریت'),
        _buildListTile(context, index: 5, icon: Icons.support_agent_outlined, title: 'پشتیبانی'),
      ],
    );
  }

  Widget _buildListTile(BuildContext context, {required int index, required IconData icon, required String title}) {
    final bool isSelected = selectedIndex == index;
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      selected: isSelected,
      selectedTileColor: Colors.blue.withOpacity(0.1),
      onTap: () => onItemSelected(index),
    );
  }

  // این متد استاتیک، لیست آیتم‌ها را برای حالت دسکتاپ (NavigationRail) فراهم می‌کند
  static List<NavigationRailDestination> getDestinations() {
    return const [
      NavigationRailDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: Text('پیشخوان')),
      NavigationRailDestination(icon: Icon(Icons.folder_copy_outlined), selectedIcon: Icon(Icons.folder_copy), label: Text('پروژه‌ها')),
      NavigationRailDestination(icon: Icon(Icons.history_edu_outlined), selectedIcon: Icon(Icons.history_edu), label: Text('گزارش فعالیت')),
      NavigationRailDestination(icon: Icon(Icons.monetization_on_outlined), selectedIcon: Icon(Icons.monetization_on), label: Text('گزارش مالی')),
      NavigationRailDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: Text('مدیریت')),
      NavigationRailDestination(icon: Icon(Icons.support_agent_outlined), selectedIcon: Icon(Icons.support_agent), label: Text('پشتیبانی')),
    ];
  }
}