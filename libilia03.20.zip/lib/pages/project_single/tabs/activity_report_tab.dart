import 'package:flutter/material.dart';

class ActivityReportTab extends StatelessWidget {
  const ActivityReportTab({super.key});
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(16.0),
      child: Text('اینجا گزارش کلی فعالیت‌های انجام شده در پروژه نمایش داده می‌شود...'),
    );
  }
}