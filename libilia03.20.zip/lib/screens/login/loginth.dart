import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:ui'; // برای ImageFilter.blur

// فرض می‌کنیم این فایل‌ها در پروژه شما وجود دارند و استایل‌ها و کامپوننت‌های سفارشی شما را شامل می‌شوند.
// اگر این فایل‌ها واقعاً وجود دارند، نیازی به تعریف دوباره آن‌ها نیست.
// در غیر این صورت، این تعاریف ساده برای اجرای کد ضروری هستند.

class MyPadings {
  static const EdgeInsets large = EdgeInsets.all(32.0); // پدینگ بزرگتر
  static const EdgeInsets medium = EdgeInsets.all(16.0);
  static const EdgeInsets defaultPadding = EdgeInsets.all(20.0); // پدینگ پیش‌فرض
}

class RespCont extends StatelessWidget {
  final Widget child;
  const RespCont({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 650), // حداکثر عرض بیشتر برای فرم در وب
        child: child,
      ),
    );
  }
}

class MyButton extends StatelessWidget {
  final VoidCallback ontap;
  final String matn;
  final Color? buttonColor;
  final Color? textColor;

  const MyButton({
    Key? key,
    required this.ontap,
    required this.matn,
    this.buttonColor,
    this.textColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: ontap,
      style: ElevatedButton.styleFrom(
        foregroundColor: textColor ?? Colors.white,
        backgroundColor: buttonColor ?? Theme.of(context).primaryColor,
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 18), // پدینگ بیشتر
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15), // گردی بیشتر لبه‌ها
        ),
        minimumSize: const Size(200, 60), // حداقل اندازه بزرگ‌تر و شیک‌تر
        elevation: 8, // سایه قوی‌تر
        shadowColor: Colors.black.withOpacity(0.4),
      ),
      child: Text(
        matn,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), // فونت بزرگ‌تر
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String? selectedRole;

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  // تابع برای نمایش اسنک‌بار شیشه‌ای
  void showGlassSnackbar(String title, String message, Color color) {
    Get.snackbar(
      title,
      message,
      titleText: Text(
        title,
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
        textAlign: TextAlign.right,
      ),
      messageText: Text(
        message,
        style: const TextStyle(color: Colors.white70, fontSize: 14),
        textAlign: TextAlign.right,
      ),
      snackPosition: SnackPosition.TOP,
      backgroundColor: Colors.transparent, // پس‌زمینه اسنک‌بار شفاف
      barBlur: 20, // میزان بلور
      overlayColor: Colors.black.withOpacity(0.1), // رنگ روی هم قرار گرفته برای جلوه بهتر
      borderColor: color.withOpacity(0.5), // خط دور
      borderWidth: 1.5,
      margin: MyPadings.defaultPadding,
      padding: MyPadings.defaultPadding,
      duration: const Duration(seconds: 3),
      animationDuration: const Duration(milliseconds: 600),
      isDismissible: true,
      forwardAnimationCurve: Curves.easeOutBack,
      reverseAnimationCurve: Curves.easeInBack,
      leftBarIndicatorColor: color, // نوار کناری رنگی
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary; // رنگ مکمل (در اینجا زرد/نارنجی)

    return Scaffold(
      extendBodyBehindAppBar: true, // برای اینکه گرادیان پشت AppBar هم باشه
      appBar: AppBar(
        title: const Text(
          "ورود به سیستم",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent, // AppBar کاملا شفاف
        elevation: 0, // بدون سایه AppBar
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        // پس‌زمینه گرادیان برای شیک‌تر شدن
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color.fromARGB(255, 0, 43, 117), // آبی تیره
              const Color.fromARGB(255, 24, 86, 192), // آبی تیره
              const Color.fromARGB(255, 48, 124, 255), // آبی تیره

            ],
          ),
        ),
        child: RespCont(
          child: SingleChildScrollView(
            padding: MyPadings.large,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 100), // فضای خالی برای زیر AppBar

                // لوگو یا تصویر
                Padding(
                  padding: const EdgeInsets.only(bottom: 40),
                  child: Image.asset(
                    'assets/images/logo.png', // مسیر لوگوی شما
                    height: 180, // اندازه بزرگتر برای لوگو
                    width: 180,
                    fit: BoxFit.contain,
                    // optional: colorBlendMode: BlendMode.modulate, // برای ترکیب رنگ لوگو با پس زمینه
                  ),
                ),

                // Card اصلی حاوی فرم ورود
                Card(
                  elevation: 15, // سایه قوی‌تر برای کارت
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25), // لبه‌های گردتر
                  ),
                  shadowColor: Colors.black.withOpacity(0.6), // سایه تیره‌تر
                  color: Colors.white.withOpacity(0.95), // کمی شفافیت برای کارت
                  child: Padding(
                    padding: MyPadings.large,
                    child: Column(
                      children: [
                        Text(
                          'به اپلیکیشن بتن خوش آمدید!',
                          style: theme.textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w900, // خیلی خیلی bold
                            color: primaryColor,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 15),
                        Text(
                          'لطفاً نقش خود را برای ورود انتخاب کنید:',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: Colors.grey.shade700,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 40),

                        // دکمه‌های انتخاب نقش
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: MyButton(
                                ontap: () {
                                  setState(() {
                                    selectedRole = 'پیمانکار';
                                    usernameController.clear();
                                    passwordController.clear();
                                  });
                                },
                                matn: 'پیمانکار',
                                buttonColor: selectedRole == 'پیمانکار'
                                    ? accentColor // رنگ مکمل برای انتخاب شده
                                    : primaryColor.withOpacity(0.9), // کمی شفاف‌تر برای انتخاب نشده
                                textColor: selectedRole == 'پیمانکار' ? Colors.black87 : Colors.white,
                              ),
                            ),
                            const SizedBox(width: 25), // فاصله بیشتر
                            Expanded(
                              child: MyButton(
                                ontap: () {
                                  setState(() {
                                    selectedRole = 'کارفرما';
                                    usernameController.clear();
                                    passwordController.clear();
                                  });
                                },
                                matn: 'کارفرما',
                                buttonColor: selectedRole == 'کارفرما'
                                    ? accentColor
                                    : primaryColor.withOpacity(0.9),
                                textColor: selectedRole == 'کارفرما' ? Colors.black87 : Colors.white,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 50),

                        // فرم ورود پس از انتخاب نقش
                        if (selectedRole != null)
                          Column(
                            children: [
                              Text(
                                "ورود به حساب کاربری $selectedRole",
                                style: theme.textTheme.headlineSmall?.copyWith(
                                  color: primaryColor,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 30),

                              // فیلد نام کاربری
                              TextField(
                                controller: usernameController,
                                textAlign: TextAlign.right,
                                textDirection: TextDirection.rtl,
                                decoration: InputDecoration(
                                  labelText: 'نام کاربری',
                                  labelStyle: TextStyle(color: primaryColor.withOpacity(0.8)),
                                  hintText: 'مثال: username123',
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15), // گردی بیشتر
                                    borderSide: BorderSide(color: Colors.blueAccent),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: BorderSide(color: accentColor, width: 3), // خط برجسته‌تر
                                  ),
                                  prefixIcon: Icon(Icons.person_outline, color: primaryColor),
                                  filled: true,
                                  fillColor: Colors.blue.shade50.withOpacity(0.6), // کمی شفافیت
                                ),
                              ),
                              const SizedBox(height: 25),

                              // فیلد رمز عبور
                              TextField(
                                controller: passwordController,
                                obscureText: true,
                                textAlign: TextAlign.right,
                                textDirection: TextDirection.rtl,
                                decoration: InputDecoration(
                                  labelText: 'رمز عبور',
                                  labelStyle: TextStyle(color: primaryColor.withOpacity(0.8)),
                                  hintText: 'حداقل ۸ کاراکتر',
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: BorderSide(color: Colors.blueAccent),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: BorderSide(color: accentColor, width: 3),
                                  ),
                                  prefixIcon: Icon(Icons.lock_outline, color: primaryColor),
                                  filled: true,
                                  fillColor: Colors.blue.shade50.withOpacity(0.6),
                                ),
                              ),
                              const SizedBox(height: 30),

                              // بخش فراموشی رمز عبور و ثبت نام
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TextButton(
                                    onPressed: () {
                                      showGlassSnackbar(
                                        'فراموشی رمز عبور',
                                        'لطفاً برای بازیابی رمز عبور به بخش پشتیبانی مراجعه کنید.',
                                        Colors.orange.shade700,
                                      );
                                    },
                                    child: Text(
                                      "فراموشی رمز عبور؟",
                                      style: TextStyle(
                                        color: Colors.blueAccent,
                                        fontWeight: FontWeight.w700,
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      showGlassSnackbar(
                                        'ثبت نام',
                                        'لطفاً فرم ثبت نام را تکمیل کنید.',
                                        Colors.green.shade700,
                                      );
                                    },
                                    child: Text(
                                      "ثبت نام",
                                      style: TextStyle(
                                        color: Colors.blueAccent,
                                        fontWeight: FontWeight.w700,
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 40),

                              // دکمه ورود
                              MyButton(
                                ontap: () {
                                  if (usernameController.text.isNotEmpty &&
                                      passwordController.text.isNotEmpty) {
                                    print(
                                        "نام کاربری: ${usernameController.text}, رمز عبور: ${passwordController.text}");
                                    showGlassSnackbar(
                                      'ورود موفقیت‌آمیز',
                                      'خوش آمدید، $selectedRole گرامی!',
                                      Colors.green.shade700,
                                    );
                                    // اینجا منطق هدایت به صفحه اصلی یا داشبورد را اضافه کنید.
                                  } else {
                                    showGlassSnackbar(
                                      'خطا در ورود',
                                      'لطفاً تمامی فیلدها را پر کنید.',
                                      Colors.red.shade700,
                                    );
                                  }
                                },
                                matn: 'ورود به $selectedRole',
                                buttonColor: accentColor,
                                textColor: Colors.black,
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// کلاس MyApp برای تنظیم تم کلی اپلیکیشن
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'سیستم ورود بتن',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: Colors.blue.shade700,
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.blue,
          accentColor: Colors.amber.shade700, // طلایی تیره
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Vazirmatn', // حتماً این فونت را به پروژه اضافه کنید
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.transparent, // شفافیت کامل
          foregroundColor: Colors.white,
          elevation: 0,
          titleTextStyle: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.blue.shade300, width: 1.5),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.blue.shade400, width: 1.5),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide(color: Colors.amber.shade700, width: 3),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: Colors.red, width: 1.5),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: const BorderSide(color: Colors.red, width: 3),
          ),
          labelStyle: TextStyle(color: Colors.blue.shade800, fontWeight: FontWeight.w500),
          hintStyle: TextStyle(color: Colors.grey.shade500),
          filled: true,
          fillColor: Colors.white.withOpacity(0.7), // پس‌زمینه فیلد کمی شفاف‌تر
          contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Colors.blue.shade700,
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 18),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            elevation: 8,
            shadowColor: Colors.black.withOpacity(0.5),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: Colors.blue.shade800,
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
        ),
      ),
      home: const LoginPage(),
    );
  }
}