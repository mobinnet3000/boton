import 'dart:ui';

import 'package:flutter/material.dart';

class MyCollors {
  MyCollors._();
  static const Color firstcolor = Color(0xff183B4E);
  static const Color prmrycolor = Color(0xffDDA853);
  static const Color floatbottmbghover = Color.fromARGB(255, 233, 151, 18);
  static const Color appbarcolor = Color(0xff27548A);
  static const Color projjectsubtitlecolor = Color.fromARGB(255, 255, 235, 202);
}
