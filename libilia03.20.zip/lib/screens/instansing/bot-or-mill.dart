import 'package:boton/components/my_button.dart';
import 'package:boton/components/responsivcont.dart';
import 'package:boton/constants/mypaddings.dart';
import 'package:boton/constants/text_style.dart';
import 'package:boton/screens/instansing/moq-or-chak.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BotOrMill extends StatelessWidget {
  const BotOrMill({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RespCont(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: MyPadings.large,
              child: Text(
                'لطفا یکی از موارد زیر را انتخاب کنید',
                style: largtitletext,
              ),
            ),
            MyButton(
              ontap: () {
                Get.to(MoqOrChak());
              },
              matn: 'بتن',
            ),
            MyButton(
              ontap: () {
                Get.snackbar(
                  'خطا',
                  """
      این مورد در بروزرسانی های آینده اضافه خواهد شد
      از بروز بودن ورژن برنامه خود اطمینان حاصل فرمایید""",
                  backgroundColor: const Color.fromARGB(125, 243, 57, 44),
                );
              },
              matn: 'میلگرد',
            ),
          ],
        ),
      ),
    );
  }
}
